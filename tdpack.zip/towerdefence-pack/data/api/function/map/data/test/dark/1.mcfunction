data modify storage map test.dark.round append value {}
data modify storage map test.dark.round[0].tick_0 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[0].tick_30 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[0].tick_60 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[0].end set value 60
