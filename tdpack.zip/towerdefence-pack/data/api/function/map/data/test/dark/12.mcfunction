data modify storage map test.dark.round append value {}
data modify storage map test.dark.round[11].tick_19 set value {difficulty:dark,map:test,model:stray}
data modify storage map test.dark.round[11].tick_99 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[11].tick_119 set value {difficulty:dark,map:test,model:stray}
data modify storage map test.dark.round[11].tick_149 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[11].tick_199 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[11].end set value 199
