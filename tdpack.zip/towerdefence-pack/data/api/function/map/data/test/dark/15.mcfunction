data modify storage map test.dark.round append value {}
data modify storage map test.dark.round[14].tick_19 set value {difficulty:dark,map:test,model:bogged}
data modify storage map test.dark.round[14].tick_119 set value {difficulty:dark,map:test,model:bogged}
data modify storage map test.dark.round[14].tick_219 set value {difficulty:dark,map:test,model:bogged}
data modify storage map test.dark.round[14].end set value 219
