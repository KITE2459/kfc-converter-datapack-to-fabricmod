data modify storage map test.dark.round append value {}
data modify storage map test.dark.round[16].tick_0 set value {difficulty:dark,map:test,model:dark}
data modify storage map test.dark.round[16].tick_29 set value {difficulty:dark,map:test,model:heavy-dark}
data modify storage map test.dark.round[16].tick_34 set value {difficulty:dark,map:test,model:dark}
data modify storage map test.dark.round[16].tick_69 set value {difficulty:dark,map:test,model:dark}
data modify storage map test.dark.round[16].tick_104 set value {difficulty:dark,map:test,model:dark}
data modify storage map test.dark.round[16].end set value 104
