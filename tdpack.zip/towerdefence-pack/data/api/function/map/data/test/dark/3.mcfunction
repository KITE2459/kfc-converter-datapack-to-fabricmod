data modify storage map test.dark.round append value {}
data modify storage map test.dark.round[2].tick_0 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[2].tick_1 set value {difficulty:dark,map:test,model:corrupted-husk}
data modify storage map test.dark.round[2].tick_30 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[2].tick_60 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[2].tick_90 set value {difficulty:dark,map:test,model:corrupted-zombie}
data modify storage map test.dark.round[2].tick_100 set value {difficulty:dark,map:test,model:corrupted-husk}
data modify storage map test.dark.round[2].end set value 100
