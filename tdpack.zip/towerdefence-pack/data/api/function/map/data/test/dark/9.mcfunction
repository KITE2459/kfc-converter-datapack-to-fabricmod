data modify storage map test.dark.round append value {}
data modify storage map test.dark.round[8].tick_0 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[8].tick_49 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[8].tick_99 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[8].tick_149 set value {difficulty:dark,map:test,model:zoglin}
data modify storage map test.dark.round[8].end set value 149
