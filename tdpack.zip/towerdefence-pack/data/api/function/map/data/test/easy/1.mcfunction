data modify storage map test.easy.round append value {} 
data modify storage map test.easy.round[0].tick_0 set value {difficulty:easy,map:test,model:zombie}
data modify storage map test.easy.round[0].tick_20 set value {difficulty:easy,map:test,model:zombie}
data modify storage map test.easy.round[0].tick_40 set value {difficulty:easy,map:test,model:zombie}
data modify storage map test.easy.round[0].end set value 40
