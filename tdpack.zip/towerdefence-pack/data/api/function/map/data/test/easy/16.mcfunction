data modify storage map test.easy.round append value {}
data modify storage map test.easy.round[15].tick_0 set value {difficulty:easy,map:test,model:spider}
data modify storage map test.easy.round[15].tick_24 set value {difficulty:easy,map:test,model:giant}
data modify storage map test.easy.round[15].tick_49 set value {difficulty:easy,map:test,model:spider}
data modify storage map test.easy.round[15].tick_99 set value {difficulty:easy,map:test,model:spider}
data modify storage map test.easy.round[15].tick_149 set value {difficulty:easy,map:test,model:spider}
data modify storage map test.easy.round[15].tick_199 set value {difficulty:easy,map:test,model:spider}
data modify storage map test.easy.round[15].end set value 199
