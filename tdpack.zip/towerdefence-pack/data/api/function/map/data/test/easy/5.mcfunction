data modify storage map test.easy.round append value {}
data modify storage map test.easy.round[4].tick_0 set value {difficulty:easy,map:test,model:heavy-zombie}
data modify storage map test.easy.round[4].tick_9 set value {difficulty:easy,map:test,model:zombie}
data modify storage map test.easy.round[4].tick_39 set value {difficulty:easy,map:test,model:zombie}
data modify storage map test.easy.round[4].tick_74 set value {difficulty:easy,map:test,model:heavy-zombie}
data modify storage map test.easy.round[4].tick_89 set value {difficulty:easy,map:test,model:zombie}
data modify storage map test.easy.round[4].end set value 89
