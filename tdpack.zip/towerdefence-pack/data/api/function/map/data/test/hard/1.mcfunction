data modify storage map test.hard.round append value {}
data modify storage map test.hard.round[0].tick_0 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[0].tick_30 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[0].tick_60 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[0].end set value 60
