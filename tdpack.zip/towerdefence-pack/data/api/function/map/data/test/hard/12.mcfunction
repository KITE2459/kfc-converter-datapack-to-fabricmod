data modify storage map test.hard.round append value {}
data modify storage map test.hard.round[11].tick_0 set value {difficulty:hard,map:test,model:wither-skeleton}
data modify storage map test.hard.round[11].tick_9 set value {difficulty:hard,map:test,model:revive-zombie}
data modify storage map test.hard.round[11].tick_19 set value {difficulty:hard,map:test,model:skeleton}
data modify storage map test.hard.round[11].tick_29 set value {difficulty:hard,map:test,model:revive-zombie}
data modify storage map test.hard.round[11].tick_49 set value {difficulty:hard,map:test,model:skeleton}
data modify storage map test.hard.round[11].tick_50 set value {difficulty:hard,map:test,model:wither-skeleton}
data modify storage map test.hard.round[11].end set value 50
