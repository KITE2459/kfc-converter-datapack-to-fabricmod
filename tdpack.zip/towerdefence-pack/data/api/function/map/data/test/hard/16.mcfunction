data modify storage map test.hard.round append value {}
data modify storage map test.hard.round[15].tick_0 set value {difficulty:hard,map:test,model:vindicator}
data modify storage map test.hard.round[15].tick_24 set value {difficulty:hard,map:test,model:vindicator}
data modify storage map test.hard.round[15].tick_49 set value {difficulty:hard,map:test,model:vindicator}
data modify storage map test.hard.round[15].tick_69 set value {difficulty:hard,map:test,model:revive-zombie}
data modify storage map test.hard.round[15].tick_74 set value {difficulty:hard,map:test,model:vindicator}
data modify storage map test.hard.round[15].tick_99 set value {difficulty:hard,map:test,model:vindicator}
data modify storage map test.hard.round[15].end set value 99
