data modify storage map test.hard.round append value {}
data modify storage map test.hard.round[1].tick_0 set value {difficulty:hard,map:test,model:rabbit}
data modify storage map test.hard.round[1].tick_1 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[1].tick_30 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[1].tick_60 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[1].tick_90 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[1].tick_120 set value {difficulty:hard,map:test,model:zombie-villager}
data modify storage map test.hard.round[1].end set value 120
