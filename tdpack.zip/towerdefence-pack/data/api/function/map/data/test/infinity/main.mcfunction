data modify storage map test.infinity.setup set value {money:750,map:test,difficulty:infinity,each_money:200}
function api:map/data/test/infinity/mob
