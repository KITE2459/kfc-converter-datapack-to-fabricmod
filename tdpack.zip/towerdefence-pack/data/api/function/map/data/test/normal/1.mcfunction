data modify storage map test.normal.round append value {}
data modify storage map test.normal.round[0].tick_0 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[0].tick_40 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[0].tick_80 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[0].end set value 80
