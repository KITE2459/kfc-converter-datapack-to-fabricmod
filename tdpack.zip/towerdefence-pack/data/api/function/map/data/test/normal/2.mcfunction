data modify storage map test.normal.round append value {}
data modify storage map test.normal.round[1].tick_0 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[1].tick_20 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[1].tick_40 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[1].tick_60 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[1].tick_80 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[1].tick_100 set value {difficulty:normal,map:test,model:husk}
data modify storage map test.normal.round[1].end set value 100
