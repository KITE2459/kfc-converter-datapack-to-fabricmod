data modify storage map test.normal.round append value {}
data modify storage map test.normal.round[8].tick_0 set value {difficulty:normal,map:test,model:healing-zombie}
data modify storage map test.normal.round[8].tick_39 set value {difficulty:normal,map:test,model:healing-zombie}
data modify storage map test.normal.round[8].tick_89 set value {difficulty:normal,map:test,model:healing-zombie}
data modify storage map test.normal.round[8].tick_149 set value {difficulty:normal,map:test,model:healing-zombie}
data modify storage map test.normal.round[8].end set value 149
